import { ImageGenerator } from '@/components/ImageGenerator/ImageGenerator';

function App() {
  return <ImageGenerator />;
}

export default App;