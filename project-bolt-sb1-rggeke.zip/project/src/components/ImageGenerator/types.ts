export type Pattern = 'hexagons' | 'waves' | 'diamonds' | 'none';
export type FontFamily = 'Playfair Display' | 'Montserrat' | 'Roboto Slab' | 'Lora';

export interface ImageConfig {
  text: string;
  backgroundColor: string;
  fontSize: number;
  pattern: Pattern;
  padding: number;
  fontFamily: FontFamily;
  watermark: string;
  watermarkSize: number;
}

export interface CanvasProps {
  config: ImageConfig;
  canvasRef: React.RefObject<HTMLDivElement>;
}

export interface ControlsProps {
  config: ImageConfig;
  onChange: (config: Partial<ImageConfig>) => void;
}