import React from 'react';
import { cn } from '@/lib/utils';
import { CanvasProps } from './types';
import '@fontsource/playfair-display';
import '@fontsource/montserrat';
import '@fontsource/roboto-slab';
import '@fontsource/lora';

export const Canvas: React.FC<CanvasProps> = ({ config, canvasRef }) => {
  const patternStyle = React.useMemo(() => {
    switch (config.pattern) {
      case 'hexagons':
        return {
          backgroundImage: `linear-gradient(30deg, #ffffff 12%, transparent 12.5%, transparent 87%, #ffffff 87.5%, #ffffff),
            linear-gradient(150deg, #ffffff 12%, transparent 12.5%, transparent 87%, #ffffff 87.5%, #ffffff),
            linear-gradient(30deg, #ffffff 12%, transparent 12.5%, transparent 87%, #ffffff 87.5%, #ffffff),
            linear-gradient(150deg, #ffffff 12%, transparent 12.5%, transparent 87%, #ffffff 87.5%, #ffffff),
            linear-gradient(60deg, #ffffff77 25%, transparent 25.5%, transparent 75%, #ffffff77 75%, #ffffff77),
            linear-gradient(60deg, #ffffff77 25%, transparent 25.5%, transparent 75%, #ffffff77 75%, #ffffff77)`,
          backgroundSize: '80px 140px',
          backgroundPosition: '0 0, 0 0, 40px 70px, 40px 70px, 0 0, 40px 70px',
        };
      case 'waves':
        return {
          backgroundImage: `radial-gradient(circle at 100% 50%, transparent 20%, rgba(255,255,255,0.3) 21%, rgba(255,255,255,0.3) 34%, transparent 35%, transparent),
            radial-gradient(circle at 0% 50%, transparent 20%, rgba(255,255,255,0.3) 21%, rgba(255,255,255,0.3) 34%, transparent 35%, transparent)`,
          backgroundSize: '60px 120px',
          backgroundPosition: '0 0',
        };
      case 'diamonds':
        return {
          backgroundImage: `linear-gradient(45deg, #ffffff 25%, transparent 25%),
            linear-gradient(-45deg, #ffffff 25%, transparent 25%),
            linear-gradient(45deg, transparent 75%, #ffffff 75%),
            linear-gradient(-45deg, transparent 75%, #ffffff 75%)`,
          backgroundSize: '50px 50px',
          backgroundPosition: '0 0, 0 25px, 25px -25px, -25px 0px',
        };
      default:
        return {};
    }
  }, [config.pattern]);

  return (
    <div
      ref={canvasRef}
      className="w-[1080px] h-[1350px] relative mx-auto"
      style={{
        backgroundColor: config.backgroundColor,
      }}
    >
      <div
        className="absolute inset-0"
        style={{
          ...patternStyle,
          opacity: 0.1,
        }}
      />
      <div
        className="absolute inset-0"
        style={{
          background:
            'linear-gradient(45deg, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.3) 100%)',
        }}
      />
      <div 
        className="absolute inset-0 flex items-center justify-center"
        style={{ padding: `${config.padding}px` }}
      >
        <p
          className={cn(
            'text-center text-white font-bold break-words max-w-full',
            'leading-tight'
          )}
          style={{
            fontSize: `${config.fontSize}px`,
            textShadow: '2px 2px 10px rgba(0,0,0,0.4)',
            fontFamily: config.fontFamily,
          }}
        >
          {config.text}
        </p>
      </div>
      {config.watermark && (
        <div className="absolute bottom-4 right-6">
          <p
            className="text-white/80 font-medium"
            style={{
              fontSize: `${config.watermarkSize}px`,
              textShadow: '1px 1px 2px rgba(0,0,0,0.3)',
              fontFamily: 'Montserrat',
            }}
          >
            {config.watermark}
          </p>
        </div>
      )}
    </div>
  );
};