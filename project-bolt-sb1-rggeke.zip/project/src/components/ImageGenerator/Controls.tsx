import React from 'react';
import { HexColorPicker } from 'react-colorful';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Card } from '@/components/ui/card';
import { ChevronDown } from 'lucide-react';
import { ControlsProps, FontFamily } from './types';

export const Controls: React.FC<ControlsProps> = ({ config, onChange }) => {
  return (
    <Card className="p-6 space-y-6">
      <div className="space-y-2">
        <Label>Text (max 20 words, 100 characters)</Label>
        <Input
          value={config.text}
          onChange={(e) => {
            const text = e.target.value;
            if (
              text.split(/\s+/).length <= 20 &&
              text.length <= 100
            ) {
              onChange({ text });
            }
          }}
          placeholder="Enter your text here..."
        />
      </div>

      <div className="space-y-2">
        <Label>Font Family</Label>
        <Select
          value={config.fontFamily}
          onValueChange={(fontFamily) => onChange({ fontFamily: fontFamily as FontFamily })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select font" />
            <ChevronDown className="h-4 w-4 opacity-50" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Playfair Display">Playfair Display</SelectItem>
            <SelectItem value="Montserrat">Montserrat</SelectItem>
            <SelectItem value="Roboto Slab">Roboto Slab</SelectItem>
            <SelectItem value="Lora">Lora</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Background Color</Label>
        <HexColorPicker
          color={config.backgroundColor}
          onChange={(color) => onChange({ backgroundColor: color })}
        />
      </div>

      <div className="space-y-2">
        <Label>Font Size: {config.fontSize}px</Label>
        <Slider
          value={[config.fontSize]}
          onValueChange={([fontSize]) => onChange({ fontSize })}
          min={40}
          max={100}
          step={1}
        />
      </div>

      <div className="space-y-2">
        <Label>Padding: {config.padding}px</Label>
        <Slider
          value={[config.padding]}
          onValueChange={([padding]) => onChange({ padding })}
          min={20}
          max={120}
          step={4}
        />
      </div>

      <div className="space-y-2">
        <Label>Pattern</Label>
        <Select
          value={config.pattern}
          onValueChange={(pattern) => onChange({ pattern })}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select pattern" />
            <ChevronDown className="h-4 w-4 opacity-50" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">None</SelectItem>
            <SelectItem value="hexagons">Hexagons</SelectItem>
            <SelectItem value="waves">Waves</SelectItem>
            <SelectItem value="diamonds">Diamonds</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>Watermark</Label>
        <Input
          value={config.watermark}
          onChange={(e) => onChange({ watermark: e.target.value })}
          placeholder="@yourusername"
        />
      </div>

      <div className="space-y-2">
        <Label>Watermark Size: {config.watermarkSize}px</Label>
        <Slider
          value={[config.watermarkSize]}
          onValueChange={([watermarkSize]) => onChange({ watermarkSize })}
          min={12}
          max={24}
          step={1}
        />
      </div>
    </Card>
  );
};