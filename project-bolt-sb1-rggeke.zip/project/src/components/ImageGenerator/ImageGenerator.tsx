import React from 'react';
import { toPng } from 'html-to-image';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';
import { Canvas } from './Canvas';
import { Controls } from './Controls';
import { ImageConfig, Pattern, FontFamily } from './types';

export const ImageGenerator: React.FC = () => {
  const canvasRef = React.useRef<HTMLDivElement>(null);
  const [config, setConfig] = React.useState<ImageConfig>({
    text: 'Your LinkedIn post text here',
    backgroundColor: '#0077B5',
    fontSize: 60,
    pattern: 'hexagons' as Pattern,
    padding: 64,
    fontFamily: 'Playfair Display' as FontFamily,
    watermark: '@knockabid',
    watermarkSize: 16,
  });

  const handleConfigChange = (newConfig: Partial<ImageConfig>) => {
    setConfig((prev) => ({ ...prev, ...newConfig }));
  };

  const handleDownload = async () => {
    if (!canvasRef.current) return;

    try {
      const dataUrl = await toPng(canvasRef.current, {
        quality: 1.0,
        width: 1080,
        height: 1350,
      });

      const link = document.createElement('a');
      link.download = 'linkedin-post.png';
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Failed to generate image:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-[1400px] mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-8">
          <div className="relative">
            <div className="sticky top-8 overflow-hidden rounded-lg shadow-lg">
              <div className="bg-white p-4">
                <div className="overflow-auto max-h-[calc(100vh-8rem)]">
                  <div className="transform scale-[0.4] origin-top">
                    <Canvas config={config} canvasRef={canvasRef} />
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <Controls config={config} onChange={handleConfigChange} />
            <Button
              className="w-full"
              size="lg"
              onClick={handleDownload}
            >
              <Download className="mr-2 h-4 w-4" />
              Download Image
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};